JARVIS Android 14 - প্রাথমিক Always-listening prototype

কী আছে:
- Android 14 targetSdk 34 এবং microphone foreground service permission
- Start/Stop Listening বোতাম
- Notification সহ microphone foreground service
- SpeechRecognizer-এ “Hey Jarvis” / “জার্ভিস” phrase detect করার prototype
- Voice command: flashlight, volume up/down, YouTube, WhatsApp, Chrome, camera, settings
- Text-to-speech reply

গুরুত্বপূর্ণ বাস্তব সীমাবদ্ধতা:
1) এটি production-grade wake-word engine নয়। Android SpeechRecognizer সাধারণ speech-to-text API; এটি একটানা always-on keyword spotting-এর জন্য তৈরি নয়।
2) Recognition engine বারবার session restart করে। সব ফোনে/সব speech service-এ screen-off অবস্থায় নির্ভরযোগ্য নাও হতে পারে; battery/data বেশি লাগতে পারে।
3) Android 14-এ microphone foreground service শুরু করতে অ্যাপটি visible অবস্থায় থাকতে হবে এবং microphone permission দিতে হবে। Start বোতাম চাপার পর notification দেখা যাবে।
4) Android/OEM battery optimization service বন্ধ করতে পারে। Background microphone permission বা system restriction পাশ কাটানোর চেষ্টা করা হয়নি।
5) এই prototype-এ command set সীমিত; কোনো call/message নিজে থেকে send করে না। App launch intent-ও device অনুযায়ী ভিন্ন হতে পারে।
6) প্রকৃত offline “Hey Jarvis” চাইলে Porcupine বা নিজস্ব TensorFlow Lite keyword model যোগ করতে হবে; তার জন্য model/access key ও আলাদা integration প্রয়োজন।

APK build:
1. GitHub-এ নতুন repository খুলে ZIP-এর ভেতরের সব ফাইল upload করুন।
2. Actions tab -> “Build JARVIS Android 14 APK” -> Run workflow চাপুন।
3. সফল হলে Artifacts থেকে JARVIS-Android14-APK download করুন।
4. Artifact ZIP খুলে app-debug.apk ফোনে install করুন।
5. অ্যাপ খুলে Start Hey Jarvis চাপুন, Microphone এবং Notifications অনুমতি দিন।
6. Notification থাকলে “Hey Jarvis” বলার চেষ্টা করুন। কাজের নির্ভরযোগ্যতা ফোনের Speech Recognition provider-এর ওপর নির্ভর করবে।

এটি debug APK build project; এখানে prebuilt APK অন্তর্ভুক্ত নয়।
