plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    namespace = "com.example.jarvisassistant"
    compileSdk = 35
    defaultConfig {
        applicationId = "com.example.jarvisassistant"
        minSdk = 26
        targetSdk = 34
        versionCode = 2
        versionName = "2.0"
    }
}
