package com.example.jarvisassistant

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.graphics.Color
import android.view.Gravity
import android.view.View
import android.widget.Toast

class MainActivity : Activity() {
    private lateinit var info: TextView
    private val permissionRequest = 220

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.rgb(5, 12, 28)
        window.navigationBarColor = Color.rgb(5, 12, 28)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(24, 30, 24, 30)
            setBackgroundColor(Color.rgb(5, 12, 28))
        }
        val title = TextView(this).apply {
            text = "JARVIS"
            textSize = 36f
            gravity = Gravity.CENTER
            setTextColor(Color.rgb(68, 211, 255))
        }
        val subtitle = TextView(this).apply {
            text = "ANDROID 14 • VOICE ASSISTANT"
            textSize = 13f
            gravity = Gravity.CENTER
            setTextColor(Color.LTGRAY)
        }
        info = TextView(this).apply {
            text = "Wake-word service is stopped.\nTap Start, allow microphone and notifications, then say “Hey Jarvis”."
            textSize = 16f
            gravity = Gravity.CENTER
            setTextColor(Color.WHITE)
            setPadding(8, 28, 8, 28)
        }
        val start = Button(this).apply {
            text = "START HEY JARVIS"
            setOnClickListener { requestNeededPermissionsAndStart() }
        }
        val stop = Button(this).apply {
            text = "STOP LISTENING"
            setOnClickListener {
                stopService(Intent(this@MainActivity, WakeWordService::class.java))
                info.text = "Wake-word service stopped."
            }
        }
        val settings = Button(this).apply {
            text = "APP SETTINGS"
            setOnClickListener {
                startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS).apply {
                    data = android.net.Uri.parse("package:$packageName")
                })
            }
        }
        listOf(title, subtitle, info, start, stop, settings).forEach {
            root.addView(it, LinearLayout.LayoutParams(-1, if (it == title || it == subtitle || it == info) -2 else -2).apply {
                bottomMargin = 12
            })
        }
        setContentView(root)
    }

    private fun requestNeededPermissionsAndStart() {
        val needed = mutableListOf<String>()
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED)
            needed.add(Manifest.permission.RECORD_AUDIO)
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED)
            needed.add(Manifest.permission.POST_NOTIFICATIONS)

        if (needed.isNotEmpty()) {
            requestPermissions(needed.toTypedArray(), permissionRequest)
        } else {
            startWakeService()
        }
    }

    private fun startWakeService() {
        try {
            val intent = Intent(this, WakeWordService::class.java)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) startForegroundService(intent) else startService(intent)
            info.text = "JARVIS is listening for “Hey Jarvis”. Keep the notification visible. Screen may turn off."
            Toast.makeText(this, "JARVIS listening started", Toast.LENGTH_LONG).show()
        } catch (e: Exception) {
            info.text = "Could not start microphone service: ${e.message}"
        }
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == permissionRequest) {
            val audioGranted = checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED
            if (audioGranted) startWakeService()
            else info.text = "Microphone permission is required."
        }
    }
}
