package com.example.jarvisassistant

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.Bundle
import android.os.IBinder
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.media.AudioManager
import android.hardware.camera2.CameraManager
import android.content.Context
import android.speech.tts.TextToSpeech
import java.util.Locale

class WakeWordService : Service(), TextToSpeech.OnInitListener {
    private var recognizer: SpeechRecognizer? = null
    private var tts: TextToSpeech? = null
    private var torchOn = false
    private var restarting = false

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()
        val notification = buildNotification("Waiting for “Hey Jarvis”")
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(77, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
        } else {
            startForeground(77, notification)
        }
        tts = TextToSpeech(this, this)
        beginRecognition()
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            val channel = NotificationChannel("jarvis_mic", "JARVIS microphone", NotificationManager.IMPORTANCE_LOW)
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
    }

    private fun buildNotification(message: String): Notification {
        val open = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        return if (Build.VERSION.SDK_INT >= 26) {
            Notification.Builder(this, "jarvis_mic")
                .setContentTitle("JARVIS is active")
                .setContentText(message)
                .setSmallIcon(android.R.drawable.ic_btn_speak_now)
                .setContentIntent(open)
                .setOngoing(true)
                .build()
        } else {
            @Suppress("DEPRECATION")
            Notification.Builder(this)
                .setContentTitle("JARVIS is active")
                .setContentText(message)
                .setSmallIcon(android.R.drawable.ic_btn_speak_now)
                .setContentIntent(open)
                .setOngoing(true)
                .build()
        }
    }

    private fun updateNotification(message: String) {
        getSystemService(NotificationManager::class.java).notify(77, buildNotification(message))
    }

    private fun beginRecognition() {
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            updateNotification("Speech recognition is unavailable on this device")
            return
        }
        try {
            recognizer?.destroy()
            recognizer = SpeechRecognizer.createSpeechRecognizer(this)
            recognizer?.setRecognitionListener(object : RecognitionListener {
                override fun onReadyForSpeech(params: Bundle?) { updateNotification("Listening for “Hey Jarvis”") }
                override fun onBeginningOfSpeech() {}
                override fun onRmsChanged(rmsdB: Float) {}
                override fun onBufferReceived(buffer: ByteArray?) {}
                override fun onEndOfSpeech() {}
                override fun onError(error: Int) { scheduleRestart() }
                override fun onResults(results: Bundle?) {
                    val matches = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                    val phrase = matches?.firstOrNull()?.lowercase(Locale.ROOT).orEmpty()
                    if (phrase.contains("hey jarvis") || phrase.contains("হে জার্ভিস") || phrase.contains("জার্ভিস")) {
                        val command = phrase.replace("hey jarvis", "").replace("হে জার্ভিস", "").replace("জার্ভিস", "").trim()
                        if (command.isNotBlank()) executeCommand(command)
                        else speak("Yes, how can I help?")
                    }
                    scheduleRestart()
                }
                override fun onPartialResults(partialResults: Bundle?) {
                    val phrase = partialResults?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()?.lowercase(Locale.ROOT).orEmpty()
                    if (phrase.contains("hey jarvis") || phrase.contains("জার্ভিস")) {
                        updateNotification("JARVIS activated")
                    }
                }
                override fun onEvent(eventType: Int, params: Bundle?) {}
            })
            val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                putExtra(RecognizerIntent.EXTRA_LANGUAGE, "en-IN")
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, "en-IN")
                putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
                putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3)
            }
            recognizer?.startListening(intent)
        } catch (_: Exception) { scheduleRestart() }
    }

    private fun scheduleRestart() {
        if (restarting) return
        restarting = true
        android.os.Handler(mainLooper).postDelayed({
            restarting = false
            if (recognizer != null) beginRecognition()
        }, 1200)
    }

    private fun executeCommand(command: String) {
        when {
            command.contains("flash") || command.contains("টর্চ") -> toggleTorch()
            command.contains("volume up") || command.contains("ভলিউম বাড়") ->
                (getSystemService(AUDIO_SERVICE) as AudioManager).adjustVolume(AudioManager.ADJUST_RAISE, AudioManager.FLAG_SHOW_UI)
            command.contains("volume down") || command.contains("ভলিউম কম") ->
                (getSystemService(AUDIO_SERVICE) as AudioManager).adjustVolume(AudioManager.ADJUST_LOWER, AudioManager.FLAG_SHOW_UI)
            command.contains("youtube") -> openApp("com.google.android.youtube", "YouTube")
            command.contains("whatsapp") -> openApp("com.whatsapp", "WhatsApp")
            command.contains("chrome") -> openApp("com.android.chrome", "Chrome")
            command.contains("camera") || command.contains("ক্যামেরা") ->
                launch(Intent("android.media.action.IMAGE_CAPTURE"), "Opening camera")
            command.contains("settings") || command.contains("সেটিং") ->
                launch(Intent(android.provider.Settings.ACTION_SETTINGS), "Opening settings")
            else -> speak("I heard $command. This command is not configured yet.")
        }
    }

    private fun toggleTorch() {
        try {
            val manager = getSystemService(Context.CAMERA_SERVICE) as CameraManager
            val id = manager.cameraIdList.firstOrNull {
                manager.getCameraCharacteristics(it).get(android.hardware.camera2.CameraCharacteristics.FLASH_INFO_AVAILABLE) == true
            }
            if (id == null) { speak("Flashlight is not available"); return }
            torchOn = !torchOn
            manager.setTorchMode(id, torchOn)
            speak(if (torchOn) "Flashlight on" else "Flashlight off")
        } catch (_: Exception) { speak("I could not control the flashlight") }
    }

    private fun openApp(packageName: String, name: String) {
        val launch = packageManager.getLaunchIntentForPackage(packageName)
        if (launch != null) launch(launch, "Opening $name") else speak("$name is not installed")
    }

    private fun launch(intent: Intent, message: String) {
        try {
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            startActivity(intent)
            speak(message)
        } catch (_: Exception) { speak("That feature is not available") }
    }

    private fun speak(message: String) {
        updateNotification(message)
        tts?.speak(message, TextToSpeech.QUEUE_FLUSH, null, "jarvis")
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) tts?.language = Locale("en", "IN")
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int = START_STICKY

    override fun onDestroy() {
        recognizer?.destroy()
        recognizer = null
        tts?.stop()
        tts?.shutdown()
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
